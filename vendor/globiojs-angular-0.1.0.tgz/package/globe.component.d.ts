import { AfterViewInit, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { type ArcConfig, type AtmosphereConfig, type AutoRotateConfig, type CinematicConfig, type CountriesConfig, type CountryDataMap, type CountryEvent, type CountryLabelsConfig, type DottedConfig, type FramingConfig, type GlobeConfig, type GlobeInstance, type GlobeKind, type GlobeMode, type HologramConfig, type HtmlMarkerConfig, type LatLng, type MarkerConfig, type MarkerEvent, type OutlineConfig, type PaperConfig, type PerformanceConfig, type PostProcessingConfig, type StarfieldConfig, type StoryCompleteEvent, type StorySceneEvent, type SurfaceClickEvent, type ThemeInput, type WireframeConfig, type ZoomConfig } from '@globiojs/core';
import * as i0 from "@angular/core";
/**
 * `<ng-globe>` — every `GlobeConfig` key is an input, every globe event an
 * output (`error` is exposed as `globeError` so it does not shadow the DOM
 * event), and `getInstance()` returns the engine instance for imperative
 * calls. The globe runs outside Angular's zone; outputs re-enter it.
 */
export declare class GlobeComponent implements AfterViewInit, OnChanges, OnDestroy {
    private readonly host;
    mode?: GlobeMode;
    kind?: GlobeKind;
    theme?: ThemeInput;
    countries?: CountriesConfig;
    countryLabels?: CountryLabelsConfig;
    countryData?: CountryDataMap;
    markers?: ReadonlyArray<MarkerConfig>;
    htmlMarkers?: ReadonlyArray<HtmlMarkerConfig>;
    arcs?: ReadonlyArray<ArcConfig>;
    atmosphere?: AtmosphereConfig;
    focusPulse?: GlobeConfig['focusPulse'];
    outline?: OutlineConfig;
    cinematic?: CinematicConfig;
    dotted?: DottedConfig;
    wireframe?: WireframeConfig;
    paper?: PaperConfig;
    hologram?: HologramConfig;
    starfield?: StarfieldConfig;
    postprocessing?: PostProcessingConfig;
    axisTilt?: number;
    autoRotate?: AutoRotateConfig;
    performance?: PerformanceConfig;
    initialPosition?: LatLng;
    minZoom?: number;
    maxZoom?: number;
    zoom?: ZoomConfig;
    transparent?: boolean;
    framing?: FramingConfig;
    readonly countryClick: EventEmitter<CountryEvent>;
    readonly countryHover: EventEmitter<CountryEvent | null>;
    readonly markerClick: EventEmitter<MarkerEvent>;
    readonly markerHover: EventEmitter<MarkerEvent | null>;
    readonly surfaceClick: EventEmitter<SurfaceClickEvent>;
    readonly sceneEnter: EventEmitter<StorySceneEvent>;
    readonly sceneExit: EventEmitter<StorySceneEvent>;
    readonly storyComplete: EventEmitter<StoryCompleteEvent>;
    readonly ready: EventEmitter<void>;
    readonly globeError: EventEmitter<Error>;
    private readonly platformId;
    private readonly ngZone;
    private instance;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    /** The underlying engine instance, or null before the view is initialised / after destroy. */
    getInstance(): GlobeInstance | null;
    setRotation(position: LatLng, animate?: boolean): void;
    addMarker(marker: MarkerConfig): void;
    removeMarker(id: string): void;
    resize(): void;
    private buildConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlobeComponent, "ng-globe", never, { "mode": { "alias": "mode"; "required": false; }; "kind": { "alias": "kind"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "countries": { "alias": "countries"; "required": false; }; "countryLabels": { "alias": "countryLabels"; "required": false; }; "countryData": { "alias": "countryData"; "required": false; }; "markers": { "alias": "markers"; "required": false; }; "htmlMarkers": { "alias": "htmlMarkers"; "required": false; }; "arcs": { "alias": "arcs"; "required": false; }; "atmosphere": { "alias": "atmosphere"; "required": false; }; "focusPulse": { "alias": "focusPulse"; "required": false; }; "outline": { "alias": "outline"; "required": false; }; "cinematic": { "alias": "cinematic"; "required": false; }; "dotted": { "alias": "dotted"; "required": false; }; "wireframe": { "alias": "wireframe"; "required": false; }; "paper": { "alias": "paper"; "required": false; }; "hologram": { "alias": "hologram"; "required": false; }; "starfield": { "alias": "starfield"; "required": false; }; "postprocessing": { "alias": "postprocessing"; "required": false; }; "axisTilt": { "alias": "axisTilt"; "required": false; }; "autoRotate": { "alias": "autoRotate"; "required": false; }; "performance": { "alias": "performance"; "required": false; }; "initialPosition": { "alias": "initialPosition"; "required": false; }; "minZoom": { "alias": "minZoom"; "required": false; }; "maxZoom": { "alias": "maxZoom"; "required": false; }; "zoom": { "alias": "zoom"; "required": false; }; "transparent": { "alias": "transparent"; "required": false; }; "framing": { "alias": "framing"; "required": false; }; }, { "countryClick": "countryClick"; "countryHover": "countryHover"; "markerClick": "markerClick"; "markerHover": "markerHover"; "surfaceClick": "surfaceClick"; "sceneEnter": "sceneEnter"; "sceneExit": "sceneExit"; "storyComplete": "storyComplete"; "ready": "ready"; "globeError": "globeError"; }, never, never, true, never>;
}
//# sourceMappingURL=globe.component.d.ts.map