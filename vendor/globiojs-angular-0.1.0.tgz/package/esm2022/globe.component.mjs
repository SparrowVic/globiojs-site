import { ChangeDetectionStrategy, Component, EventEmitter, Input, NgZone, Output, PLATFORM_ID, ViewChild, inject, } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { createGlobe, pickGlobeConfig, } from '@globiojs/core';
import * as i0 from "@angular/core";
/**
 * `<ng-globe>` — every `GlobeConfig` key is an input, every globe event an
 * output (`error` is exposed as `globeError` so it does not shadow the DOM
 * event), and `getInstance()` returns the engine instance for imperative
 * calls. The globe runs outside Angular's zone; outputs re-enter it.
 */
export class GlobeComponent {
    constructor() {
        this.countryClick = new EventEmitter();
        this.countryHover = new EventEmitter();
        this.markerClick = new EventEmitter();
        this.markerHover = new EventEmitter();
        this.surfaceClick = new EventEmitter();
        this.sceneEnter = new EventEmitter();
        this.sceneExit = new EventEmitter();
        this.storyComplete = new EventEmitter();
        this.ready = new EventEmitter();
        this.globeError = new EventEmitter();
        this.platformId = inject(PLATFORM_ID);
        this.ngZone = inject(NgZone);
        this.instance = null;
    }
    ngAfterViewInit() {
        if (!isPlatformBrowser(this.platformId))
            return;
        this.ngZone.runOutsideAngular(() => {
            const instance = createGlobe({
                container: this.host.nativeElement,
                ...this.buildConfig(),
            });
            instance.on('countryClick', (e) => this.ngZone.run(() => this.countryClick.emit(e)));
            instance.on('countryHover', (e) => this.ngZone.run(() => this.countryHover.emit(e)));
            instance.on('markerClick', (e) => this.ngZone.run(() => this.markerClick.emit(e)));
            instance.on('markerHover', (e) => this.ngZone.run(() => this.markerHover.emit(e)));
            instance.on('surfaceClick', (e) => this.ngZone.run(() => this.surfaceClick.emit(e)));
            instance.on('sceneEnter', (e) => this.ngZone.run(() => this.sceneEnter.emit(e)));
            instance.on('sceneExit', (e) => this.ngZone.run(() => this.sceneExit.emit(e)));
            instance.on('storyComplete', (e) => this.ngZone.run(() => this.storyComplete.emit(e)));
            instance.on('ready', () => this.ngZone.run(() => this.ready.emit()));
            instance.on('error', (err) => this.ngZone.run(() => this.globeError.emit(err)));
            instance.mount();
            this.instance = instance;
        });
    }
    ngOnChanges(changes) {
        if (!this.instance)
            return;
        const hasRelevantChange = Object.keys(changes).some((key) => !changes[key]?.firstChange);
        if (hasRelevantChange) {
            this.ngZone.runOutsideAngular(() => this.instance?.update(this.buildConfig()));
        }
    }
    ngOnDestroy() {
        this.instance?.destroy();
        this.instance = null;
    }
    /** The underlying engine instance, or null before the view is initialised / after destroy. */
    getInstance() {
        return this.instance;
    }
    setRotation(position, animate) {
        this.instance?.setRotation(position, animate);
    }
    addMarker(marker) {
        this.instance?.addMarker(marker);
    }
    removeMarker(id) {
        this.instance?.removeMarker(id);
    }
    resize() {
        this.instance?.resize();
    }
    buildConfig() {
        return pickGlobeConfig(this);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GlobeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GlobeComponent, isStandalone: true, selector: "ng-globe", inputs: { mode: "mode", kind: "kind", theme: "theme", countries: "countries", countryLabels: "countryLabels", countryData: "countryData", markers: "markers", htmlMarkers: "htmlMarkers", arcs: "arcs", atmosphere: "atmosphere", focusPulse: "focusPulse", outline: "outline", cinematic: "cinematic", dotted: "dotted", wireframe: "wireframe", paper: "paper", hologram: "hologram", starfield: "starfield", postprocessing: "postprocessing", axisTilt: "axisTilt", autoRotate: "autoRotate", performance: "performance", initialPosition: "initialPosition", minZoom: "minZoom", maxZoom: "maxZoom", zoom: "zoom", transparent: "transparent", framing: "framing" }, outputs: { countryClick: "countryClick", countryHover: "countryHover", markerClick: "markerClick", markerHover: "markerHover", surfaceClick: "surfaceClick", sceneEnter: "sceneEnter", sceneExit: "sceneExit", storyComplete: "storyComplete", ready: "ready", globeError: "globeError" }, viewQueries: [{ propertyName: "host", first: true, predicate: ["host"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: '<div #host class="globe-host"></div>', isInline: true, styles: [":host{display:block;width:100%;height:100%}.globe-host{width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GlobeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-globe', standalone: true, template: '<div #host class="globe-host"></div>', changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;width:100%;height:100%}.globe-host{width:100%;height:100%}\n"] }]
        }], propDecorators: { host: [{
                type: ViewChild,
                args: ['host', { static: true }]
            }], mode: [{
                type: Input
            }], kind: [{
                type: Input
            }], theme: [{
                type: Input
            }], countries: [{
                type: Input
            }], countryLabels: [{
                type: Input
            }], countryData: [{
                type: Input
            }], markers: [{
                type: Input
            }], htmlMarkers: [{
                type: Input
            }], arcs: [{
                type: Input
            }], atmosphere: [{
                type: Input
            }], focusPulse: [{
                type: Input
            }], outline: [{
                type: Input
            }], cinematic: [{
                type: Input
            }], dotted: [{
                type: Input
            }], wireframe: [{
                type: Input
            }], paper: [{
                type: Input
            }], hologram: [{
                type: Input
            }], starfield: [{
                type: Input
            }], postprocessing: [{
                type: Input
            }], axisTilt: [{
                type: Input
            }], autoRotate: [{
                type: Input
            }], performance: [{
                type: Input
            }], initialPosition: [{
                type: Input
            }], minZoom: [{
                type: Input
            }], maxZoom: [{
                type: Input
            }], zoom: [{
                type: Input
            }], transparent: [{
                type: Input
            }], framing: [{
                type: Input
            }], countryClick: [{
                type: Output
            }], countryHover: [{
                type: Output
            }], markerClick: [{
                type: Output
            }], markerHover: [{
                type: Output
            }], surfaceClick: [{
                type: Output
            }], sceneEnter: [{
                type: Output
            }], sceneExit: [{
                type: Output
            }], storyComplete: [{
                type: Output
            }], ready: [{
                type: Output
            }], globeError: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2xvYmUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2dsb2JlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFFVCxZQUFZLEVBQ1osS0FBSyxFQUNMLE1BQU0sRUFHTixNQUFNLEVBQ04sV0FBVyxFQUVYLFNBQVMsRUFDVCxNQUFNLEdBQ1AsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDcEQsT0FBTyxFQUNMLFdBQVcsRUFDWCxlQUFlLEdBZ0NoQixNQUFNLGdCQUFnQixDQUFDOztBQUV4Qjs7Ozs7R0FLRztBQVFILE1BQU0sT0FBTyxjQUFjO0lBUDNCO1FBdUM0QixpQkFBWSxHQUFHLElBQUksWUFBWSxFQUFnQixDQUFDO1FBQ2hELGlCQUFZLEdBQUcsSUFBSSxZQUFZLEVBQXVCLENBQUM7UUFDdkQsZ0JBQVcsR0FBRyxJQUFJLFlBQVksRUFBZSxDQUFDO1FBQzlDLGdCQUFXLEdBQUcsSUFBSSxZQUFZLEVBQXNCLENBQUM7UUFDckQsaUJBQVksR0FBRyxJQUFJLFlBQVksRUFBcUIsQ0FBQztRQUNyRCxlQUFVLEdBQUcsSUFBSSxZQUFZLEVBQW1CLENBQUM7UUFDakQsY0FBUyxHQUFHLElBQUksWUFBWSxFQUFtQixDQUFDO1FBQ2hELGtCQUFhLEdBQUcsSUFBSSxZQUFZLEVBQXNCLENBQUM7UUFDdkQsVUFBSyxHQUFHLElBQUksWUFBWSxFQUFRLENBQUM7UUFDakMsZUFBVSxHQUFHLElBQUksWUFBWSxFQUFTLENBQUM7UUFFaEQsZUFBVSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNqQyxXQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLGFBQVEsR0FBeUIsSUFBSSxDQUFDO0tBZ0UvQztJQTlEUSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQUUsT0FBTztRQUVoRCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRTtZQUNqQyxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUM7Z0JBQzNCLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWE7Z0JBQ2xDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRTthQUN0QixDQUFDLENBQUM7WUFFSCxRQUFRLENBQUMsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3JGLFFBQVEsQ0FBQyxFQUFFLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckYsUUFBUSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRixRQUFRLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ25GLFFBQVEsQ0FBQyxFQUFFLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDckYsUUFBUSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqRixRQUFRLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQy9FLFFBQVEsQ0FBQyxFQUFFLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdkYsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDckUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVoRixRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sV0FBVyxDQUFDLE9BQXNCO1FBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTtZQUFFLE9BQU87UUFDM0IsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDekYsSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNqRixDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztJQUN2QixDQUFDO0lBRUQsOEZBQThGO0lBQ3ZGLFdBQVc7UUFDaEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFFTSxXQUFXLENBQUMsUUFBZ0IsRUFBRSxPQUFpQjtRQUNwRCxJQUFJLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVNLFNBQVMsQ0FBQyxNQUFvQjtRQUNuQyxJQUFJLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRU0sWUFBWSxDQUFDLEVBQVU7UUFDNUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVNLE1BQU07UUFDWCxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTyxXQUFXO1FBQ2pCLE9BQU8sZUFBZSxDQUFDLElBQTBDLENBQUMsQ0FBQztJQUNyRSxDQUFDOytHQTVHVSxjQUFjO21HQUFkLGNBQWMsMG1DQUpmLHNDQUFzQzs7NEZBSXJDLGNBQWM7a0JBUDFCLFNBQVM7K0JBQ0UsVUFBVSxjQUNSLElBQUksWUFDTixzQ0FBc0MsbUJBRS9CLHVCQUF1QixDQUFDLE1BQU07OEJBR08sSUFBSTtzQkFBekQsU0FBUzt1QkFBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO2dCQUVuQixJQUFJO3NCQUFuQixLQUFLO2dCQUNVLElBQUk7c0JBQW5CLEtBQUs7Z0JBQ1UsS0FBSztzQkFBcEIsS0FBSztnQkFDVSxTQUFTO3NCQUF4QixLQUFLO2dCQUNVLGFBQWE7c0JBQTVCLEtBQUs7Z0JBQ1UsV0FBVztzQkFBMUIsS0FBSztnQkFDVSxPQUFPO3NCQUF0QixLQUFLO2dCQUNVLFdBQVc7c0JBQTFCLEtBQUs7Z0JBQ1UsSUFBSTtzQkFBbkIsS0FBSztnQkFDVSxVQUFVO3NCQUF6QixLQUFLO2dCQUNVLFVBQVU7c0JBQXpCLEtBQUs7Z0JBQ1UsT0FBTztzQkFBdEIsS0FBSztnQkFDVSxTQUFTO3NCQUF4QixLQUFLO2dCQUNVLE1BQU07c0JBQXJCLEtBQUs7Z0JBQ1UsU0FBUztzQkFBeEIsS0FBSztnQkFDVSxLQUFLO3NCQUFwQixLQUFLO2dCQUNVLFFBQVE7c0JBQXZCLEtBQUs7Z0JBQ1UsU0FBUztzQkFBeEIsS0FBSztnQkFDVSxjQUFjO3NCQUE3QixLQUFLO2dCQUNVLFFBQVE7c0JBQXZCLEtBQUs7Z0JBQ1UsVUFBVTtzQkFBekIsS0FBSztnQkFDVSxXQUFXO3NCQUExQixLQUFLO2dCQUNVLGVBQWU7c0JBQTlCLEtBQUs7Z0JBQ1UsT0FBTztzQkFBdEIsS0FBSztnQkFDVSxPQUFPO3NCQUF0QixLQUFLO2dCQUNVLElBQUk7c0JBQW5CLEtBQUs7Z0JBQ1UsV0FBVztzQkFBMUIsS0FBSztnQkFDVSxPQUFPO3NCQUF0QixLQUFLO2dCQUVvQixZQUFZO3NCQUFyQyxNQUFNO2dCQUNtQixZQUFZO3NCQUFyQyxNQUFNO2dCQUNtQixXQUFXO3NCQUFwQyxNQUFNO2dCQUNtQixXQUFXO3NCQUFwQyxNQUFNO2dCQUNtQixZQUFZO3NCQUFyQyxNQUFNO2dCQUNtQixVQUFVO3NCQUFuQyxNQUFNO2dCQUNtQixTQUFTO3NCQUFsQyxNQUFNO2dCQUNtQixhQUFhO3NCQUF0QyxNQUFNO2dCQUNtQixLQUFLO3NCQUE5QixNQUFNO2dCQUNtQixVQUFVO3NCQUFuQyxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbnB1dCxcbiAgTmdab25lLFxuICBPbkNoYW5nZXMsXG4gIE9uRGVzdHJveSxcbiAgT3V0cHV0LFxuICBQTEFURk9STV9JRCxcbiAgU2ltcGxlQ2hhbmdlcyxcbiAgVmlld0NoaWxkLFxuICBpbmplY3QsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgaXNQbGF0Zm9ybUJyb3dzZXIgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHtcbiAgY3JlYXRlR2xvYmUsXG4gIHBpY2tHbG9iZUNvbmZpZyxcbiAgdHlwZSBBcmNDb25maWcsXG4gIHR5cGUgQXRtb3NwaGVyZUNvbmZpZyxcbiAgdHlwZSBBdXRvUm90YXRlQ29uZmlnLFxuICB0eXBlIENpbmVtYXRpY0NvbmZpZyxcbiAgdHlwZSBDb3VudHJpZXNDb25maWcsXG4gIHR5cGUgQ291bnRyeURhdGFNYXAsXG4gIHR5cGUgQ291bnRyeUV2ZW50LFxuICB0eXBlIENvdW50cnlMYWJlbHNDb25maWcsXG4gIHR5cGUgRG90dGVkQ29uZmlnLFxuICB0eXBlIEZyYW1pbmdDb25maWcsXG4gIHR5cGUgR2xvYmVDb25maWcsXG4gIHR5cGUgR2xvYmVDb25maWdJbnB1dCxcbiAgdHlwZSBHbG9iZUluc3RhbmNlLFxuICB0eXBlIEdsb2JlS2luZCxcbiAgdHlwZSBHbG9iZU1vZGUsXG4gIHR5cGUgSG9sb2dyYW1Db25maWcsXG4gIHR5cGUgSHRtbE1hcmtlckNvbmZpZyxcbiAgdHlwZSBMYXRMbmcsXG4gIHR5cGUgTWFya2VyQ29uZmlnLFxuICB0eXBlIE1hcmtlckV2ZW50LFxuICB0eXBlIE91dGxpbmVDb25maWcsXG4gIHR5cGUgUGFwZXJDb25maWcsXG4gIHR5cGUgUGVyZm9ybWFuY2VDb25maWcsXG4gIHR5cGUgUG9zdFByb2Nlc3NpbmdDb25maWcsXG4gIHR5cGUgU3RhcmZpZWxkQ29uZmlnLFxuICB0eXBlIFN0b3J5Q29tcGxldGVFdmVudCxcbiAgdHlwZSBTdG9yeVNjZW5lRXZlbnQsXG4gIHR5cGUgU3VyZmFjZUNsaWNrRXZlbnQsXG4gIHR5cGUgVGhlbWVJbnB1dCxcbiAgdHlwZSBXaXJlZnJhbWVDb25maWcsXG4gIHR5cGUgWm9vbUNvbmZpZyxcbn0gZnJvbSAnQGdsb2Jpb2pzL2NvcmUnO1xuXG4vKipcbiAqIGA8bmctZ2xvYmU+YCDigJQgZXZlcnkgYEdsb2JlQ29uZmlnYCBrZXkgaXMgYW4gaW5wdXQsIGV2ZXJ5IGdsb2JlIGV2ZW50IGFuXG4gKiBvdXRwdXQgKGBlcnJvcmAgaXMgZXhwb3NlZCBhcyBgZ2xvYmVFcnJvcmAgc28gaXQgZG9lcyBub3Qgc2hhZG93IHRoZSBET01cbiAqIGV2ZW50KSwgYW5kIGBnZXRJbnN0YW5jZSgpYCByZXR1cm5zIHRoZSBlbmdpbmUgaW5zdGFuY2UgZm9yIGltcGVyYXRpdmVcbiAqIGNhbGxzLiBUaGUgZ2xvYmUgcnVucyBvdXRzaWRlIEFuZ3VsYXIncyB6b25lOyBvdXRwdXRzIHJlLWVudGVyIGl0LlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICduZy1nbG9iZScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHRlbXBsYXRlOiAnPGRpdiAjaG9zdCBjbGFzcz1cImdsb2JlLWhvc3RcIj48L2Rpdj4nLFxuICBzdHlsZXM6IFsnOmhvc3R7ZGlzcGxheTpibG9jazt3aWR0aDoxMDAlO2hlaWdodDoxMDAlfS5nbG9iZS1ob3N0e3dpZHRoOjEwMCU7aGVpZ2h0OjEwMCV9J10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBHbG9iZUNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcbiAgQFZpZXdDaGlsZCgnaG9zdCcsIHsgc3RhdGljOiB0cnVlIH0pIHByaXZhdGUgcmVhZG9ubHkgaG9zdCE6IEVsZW1lbnRSZWY8SFRNTERpdkVsZW1lbnQ+O1xuXG4gIEBJbnB1dCgpIHB1YmxpYyBtb2RlPzogR2xvYmVNb2RlO1xuICBASW5wdXQoKSBwdWJsaWMga2luZD86IEdsb2JlS2luZDtcbiAgQElucHV0KCkgcHVibGljIHRoZW1lPzogVGhlbWVJbnB1dDtcbiAgQElucHV0KCkgcHVibGljIGNvdW50cmllcz86IENvdW50cmllc0NvbmZpZztcbiAgQElucHV0KCkgcHVibGljIGNvdW50cnlMYWJlbHM/OiBDb3VudHJ5TGFiZWxzQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgY291bnRyeURhdGE/OiBDb3VudHJ5RGF0YU1hcDtcbiAgQElucHV0KCkgcHVibGljIG1hcmtlcnM/OiBSZWFkb25seUFycmF5PE1hcmtlckNvbmZpZz47XG4gIEBJbnB1dCgpIHB1YmxpYyBodG1sTWFya2Vycz86IFJlYWRvbmx5QXJyYXk8SHRtbE1hcmtlckNvbmZpZz47XG4gIEBJbnB1dCgpIHB1YmxpYyBhcmNzPzogUmVhZG9ubHlBcnJheTxBcmNDb25maWc+O1xuICBASW5wdXQoKSBwdWJsaWMgYXRtb3NwaGVyZT86IEF0bW9zcGhlcmVDb25maWc7XG4gIEBJbnB1dCgpIHB1YmxpYyBmb2N1c1B1bHNlPzogR2xvYmVDb25maWdbJ2ZvY3VzUHVsc2UnXTtcbiAgQElucHV0KCkgcHVibGljIG91dGxpbmU/OiBPdXRsaW5lQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgY2luZW1hdGljPzogQ2luZW1hdGljQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgZG90dGVkPzogRG90dGVkQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgd2lyZWZyYW1lPzogV2lyZWZyYW1lQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgcGFwZXI/OiBQYXBlckNvbmZpZztcbiAgQElucHV0KCkgcHVibGljIGhvbG9ncmFtPzogSG9sb2dyYW1Db25maWc7XG4gIEBJbnB1dCgpIHB1YmxpYyBzdGFyZmllbGQ/OiBTdGFyZmllbGRDb25maWc7XG4gIEBJbnB1dCgpIHB1YmxpYyBwb3N0cHJvY2Vzc2luZz86IFBvc3RQcm9jZXNzaW5nQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgYXhpc1RpbHQ/OiBudW1iZXI7XG4gIEBJbnB1dCgpIHB1YmxpYyBhdXRvUm90YXRlPzogQXV0b1JvdGF0ZUNvbmZpZztcbiAgQElucHV0KCkgcHVibGljIHBlcmZvcm1hbmNlPzogUGVyZm9ybWFuY2VDb25maWc7XG4gIEBJbnB1dCgpIHB1YmxpYyBpbml0aWFsUG9zaXRpb24/OiBMYXRMbmc7XG4gIEBJbnB1dCgpIHB1YmxpYyBtaW5ab29tPzogbnVtYmVyO1xuICBASW5wdXQoKSBwdWJsaWMgbWF4Wm9vbT86IG51bWJlcjtcbiAgQElucHV0KCkgcHVibGljIHpvb20/OiBab29tQ29uZmlnO1xuICBASW5wdXQoKSBwdWJsaWMgdHJhbnNwYXJlbnQ/OiBib29sZWFuO1xuICBASW5wdXQoKSBwdWJsaWMgZnJhbWluZz86IEZyYW1pbmdDb25maWc7XG5cbiAgQE91dHB1dCgpIHB1YmxpYyByZWFkb25seSBjb3VudHJ5Q2xpY2sgPSBuZXcgRXZlbnRFbWl0dGVyPENvdW50cnlFdmVudD4oKTtcbiAgQE91dHB1dCgpIHB1YmxpYyByZWFkb25seSBjb3VudHJ5SG92ZXIgPSBuZXcgRXZlbnRFbWl0dGVyPENvdW50cnlFdmVudCB8IG51bGw+KCk7XG4gIEBPdXRwdXQoKSBwdWJsaWMgcmVhZG9ubHkgbWFya2VyQ2xpY2sgPSBuZXcgRXZlbnRFbWl0dGVyPE1hcmtlckV2ZW50PigpO1xuICBAT3V0cHV0KCkgcHVibGljIHJlYWRvbmx5IG1hcmtlckhvdmVyID0gbmV3IEV2ZW50RW1pdHRlcjxNYXJrZXJFdmVudCB8IG51bGw+KCk7XG4gIEBPdXRwdXQoKSBwdWJsaWMgcmVhZG9ubHkgc3VyZmFjZUNsaWNrID0gbmV3IEV2ZW50RW1pdHRlcjxTdXJmYWNlQ2xpY2tFdmVudD4oKTtcbiAgQE91dHB1dCgpIHB1YmxpYyByZWFkb25seSBzY2VuZUVudGVyID0gbmV3IEV2ZW50RW1pdHRlcjxTdG9yeVNjZW5lRXZlbnQ+KCk7XG4gIEBPdXRwdXQoKSBwdWJsaWMgcmVhZG9ubHkgc2NlbmVFeGl0ID0gbmV3IEV2ZW50RW1pdHRlcjxTdG9yeVNjZW5lRXZlbnQ+KCk7XG4gIEBPdXRwdXQoKSBwdWJsaWMgcmVhZG9ubHkgc3RvcnlDb21wbGV0ZSA9IG5ldyBFdmVudEVtaXR0ZXI8U3RvcnlDb21wbGV0ZUV2ZW50PigpO1xuICBAT3V0cHV0KCkgcHVibGljIHJlYWRvbmx5IHJlYWR5ID0gbmV3IEV2ZW50RW1pdHRlcjx2b2lkPigpO1xuICBAT3V0cHV0KCkgcHVibGljIHJlYWRvbmx5IGdsb2JlRXJyb3IgPSBuZXcgRXZlbnRFbWl0dGVyPEVycm9yPigpO1xuXG4gIHByaXZhdGUgcmVhZG9ubHkgcGxhdGZvcm1JZCA9IGluamVjdChQTEFURk9STV9JRCk7XG4gIHByaXZhdGUgcmVhZG9ubHkgbmdab25lID0gaW5qZWN0KE5nWm9uZSk7XG4gIHByaXZhdGUgaW5zdGFuY2U6IEdsb2JlSW5zdGFuY2UgfCBudWxsID0gbnVsbDtcblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIGlmICghaXNQbGF0Zm9ybUJyb3dzZXIodGhpcy5wbGF0Zm9ybUlkKSkgcmV0dXJuO1xuXG4gICAgdGhpcy5uZ1pvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgY29uc3QgaW5zdGFuY2UgPSBjcmVhdGVHbG9iZSh7XG4gICAgICAgIGNvbnRhaW5lcjogdGhpcy5ob3N0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgIC4uLnRoaXMuYnVpbGRDb25maWcoKSxcbiAgICAgIH0pO1xuXG4gICAgICBpbnN0YW5jZS5vbignY291bnRyeUNsaWNrJywgKGUpID0+IHRoaXMubmdab25lLnJ1bigoKSA9PiB0aGlzLmNvdW50cnlDbGljay5lbWl0KGUpKSk7XG4gICAgICBpbnN0YW5jZS5vbignY291bnRyeUhvdmVyJywgKGUpID0+IHRoaXMubmdab25lLnJ1bigoKSA9PiB0aGlzLmNvdW50cnlIb3Zlci5lbWl0KGUpKSk7XG4gICAgICBpbnN0YW5jZS5vbignbWFya2VyQ2xpY2snLCAoZSkgPT4gdGhpcy5uZ1pvbmUucnVuKCgpID0+IHRoaXMubWFya2VyQ2xpY2suZW1pdChlKSkpO1xuICAgICAgaW5zdGFuY2Uub24oJ21hcmtlckhvdmVyJywgKGUpID0+IHRoaXMubmdab25lLnJ1bigoKSA9PiB0aGlzLm1hcmtlckhvdmVyLmVtaXQoZSkpKTtcbiAgICAgIGluc3RhbmNlLm9uKCdzdXJmYWNlQ2xpY2snLCAoZSkgPT4gdGhpcy5uZ1pvbmUucnVuKCgpID0+IHRoaXMuc3VyZmFjZUNsaWNrLmVtaXQoZSkpKTtcbiAgICAgIGluc3RhbmNlLm9uKCdzY2VuZUVudGVyJywgKGUpID0+IHRoaXMubmdab25lLnJ1bigoKSA9PiB0aGlzLnNjZW5lRW50ZXIuZW1pdChlKSkpO1xuICAgICAgaW5zdGFuY2Uub24oJ3NjZW5lRXhpdCcsIChlKSA9PiB0aGlzLm5nWm9uZS5ydW4oKCkgPT4gdGhpcy5zY2VuZUV4aXQuZW1pdChlKSkpO1xuICAgICAgaW5zdGFuY2Uub24oJ3N0b3J5Q29tcGxldGUnLCAoZSkgPT4gdGhpcy5uZ1pvbmUucnVuKCgpID0+IHRoaXMuc3RvcnlDb21wbGV0ZS5lbWl0KGUpKSk7XG4gICAgICBpbnN0YW5jZS5vbigncmVhZHknLCAoKSA9PiB0aGlzLm5nWm9uZS5ydW4oKCkgPT4gdGhpcy5yZWFkeS5lbWl0KCkpKTtcbiAgICAgIGluc3RhbmNlLm9uKCdlcnJvcicsIChlcnIpID0+IHRoaXMubmdab25lLnJ1bigoKSA9PiB0aGlzLmdsb2JlRXJyb3IuZW1pdChlcnIpKSk7XG5cbiAgICAgIGluc3RhbmNlLm1vdW50KCk7XG4gICAgICB0aGlzLmluc3RhbmNlID0gaW5zdGFuY2U7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xuICAgIGlmICghdGhpcy5pbnN0YW5jZSkgcmV0dXJuO1xuICAgIGNvbnN0IGhhc1JlbGV2YW50Q2hhbmdlID0gT2JqZWN0LmtleXMoY2hhbmdlcykuc29tZSgoa2V5KSA9PiAhY2hhbmdlc1trZXldPy5maXJzdENoYW5nZSk7XG4gICAgaWYgKGhhc1JlbGV2YW50Q2hhbmdlKSB7XG4gICAgICB0aGlzLm5nWm9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB0aGlzLmluc3RhbmNlPy51cGRhdGUodGhpcy5idWlsZENvbmZpZygpKSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMuaW5zdGFuY2U/LmRlc3Ryb3koKTtcbiAgICB0aGlzLmluc3RhbmNlID0gbnVsbDtcbiAgfVxuXG4gIC8qKiBUaGUgdW5kZXJseWluZyBlbmdpbmUgaW5zdGFuY2UsIG9yIG51bGwgYmVmb3JlIHRoZSB2aWV3IGlzIGluaXRpYWxpc2VkIC8gYWZ0ZXIgZGVzdHJveS4gKi9cbiAgcHVibGljIGdldEluc3RhbmNlKCk6IEdsb2JlSW5zdGFuY2UgfCBudWxsIHtcbiAgICByZXR1cm4gdGhpcy5pbnN0YW5jZTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRSb3RhdGlvbihwb3NpdGlvbjogTGF0TG5nLCBhbmltYXRlPzogYm9vbGVhbik6IHZvaWQge1xuICAgIHRoaXMuaW5zdGFuY2U/LnNldFJvdGF0aW9uKHBvc2l0aW9uLCBhbmltYXRlKTtcbiAgfVxuXG4gIHB1YmxpYyBhZGRNYXJrZXIobWFya2VyOiBNYXJrZXJDb25maWcpOiB2b2lkIHtcbiAgICB0aGlzLmluc3RhbmNlPy5hZGRNYXJrZXIobWFya2VyKTtcbiAgfVxuXG4gIHB1YmxpYyByZW1vdmVNYXJrZXIoaWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIHRoaXMuaW5zdGFuY2U/LnJlbW92ZU1hcmtlcihpZCk7XG4gIH1cblxuICBwdWJsaWMgcmVzaXplKCk6IHZvaWQge1xuICAgIHRoaXMuaW5zdGFuY2U/LnJlc2l6ZSgpO1xuICB9XG5cbiAgcHJpdmF0ZSBidWlsZENvbmZpZygpOiBHbG9iZUNvbmZpZ0lucHV0IHtcbiAgICByZXR1cm4gcGlja0dsb2JlQ29uZmlnKHRoaXMgYXMgdW5rbm93biBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik7XG4gIH1cbn1cbiJdfQ==