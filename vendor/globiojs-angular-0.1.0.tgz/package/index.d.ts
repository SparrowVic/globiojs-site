/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@globiojs/angular" />
export * from './public-api';
//# sourceMappingURL=globiojs-angular.d.ts.map