import * as i0 from '@angular/core';
import { EventEmitter, inject, PLATFORM_ID, NgZone, Output, Input, ViewChild, ChangeDetectionStrategy, Component } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { createGlobe, pickGlobeConfig } from '@globiojs/core';

/**
 * `<ng-globe>` — every `GlobeConfig` key is an input, every globe event an
 * output (`error` is exposed as `globeError` so it does not shadow the DOM
 * event), and `getInstance()` returns the engine instance for imperative
 * calls. The globe runs outside Angular's zone; outputs re-enter it.
 */
class GlobeComponent {
    constructor() {
        this.countryClick = new EventEmitter();
        this.countryHover = new EventEmitter();
        this.markerClick = new EventEmitter();
        this.markerHover = new EventEmitter();
        this.surfaceClick = new EventEmitter();
        this.sceneEnter = new EventEmitter();
        this.sceneExit = new EventEmitter();
        this.storyComplete = new EventEmitter();
        this.ready = new EventEmitter();
        this.globeError = new EventEmitter();
        this.platformId = inject(PLATFORM_ID);
        this.ngZone = inject(NgZone);
        this.instance = null;
    }
    ngAfterViewInit() {
        if (!isPlatformBrowser(this.platformId))
            return;
        this.ngZone.runOutsideAngular(() => {
            const instance = createGlobe({
                container: this.host.nativeElement,
                ...this.buildConfig(),
            });
            instance.on('countryClick', (e) => this.ngZone.run(() => this.countryClick.emit(e)));
            instance.on('countryHover', (e) => this.ngZone.run(() => this.countryHover.emit(e)));
            instance.on('markerClick', (e) => this.ngZone.run(() => this.markerClick.emit(e)));
            instance.on('markerHover', (e) => this.ngZone.run(() => this.markerHover.emit(e)));
            instance.on('surfaceClick', (e) => this.ngZone.run(() => this.surfaceClick.emit(e)));
            instance.on('sceneEnter', (e) => this.ngZone.run(() => this.sceneEnter.emit(e)));
            instance.on('sceneExit', (e) => this.ngZone.run(() => this.sceneExit.emit(e)));
            instance.on('storyComplete', (e) => this.ngZone.run(() => this.storyComplete.emit(e)));
            instance.on('ready', () => this.ngZone.run(() => this.ready.emit()));
            instance.on('error', (err) => this.ngZone.run(() => this.globeError.emit(err)));
            instance.mount();
            this.instance = instance;
        });
    }
    ngOnChanges(changes) {
        if (!this.instance)
            return;
        const hasRelevantChange = Object.keys(changes).some((key) => !changes[key]?.firstChange);
        if (hasRelevantChange) {
            this.ngZone.runOutsideAngular(() => this.instance?.update(this.buildConfig()));
        }
    }
    ngOnDestroy() {
        this.instance?.destroy();
        this.instance = null;
    }
    /** The underlying engine instance, or null before the view is initialised / after destroy. */
    getInstance() {
        return this.instance;
    }
    setRotation(position, animate) {
        this.instance?.setRotation(position, animate);
    }
    addMarker(marker) {
        this.instance?.addMarker(marker);
    }
    removeMarker(id) {
        this.instance?.removeMarker(id);
    }
    resize() {
        this.instance?.resize();
    }
    buildConfig() {
        return pickGlobeConfig(this);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GlobeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: GlobeComponent, isStandalone: true, selector: "ng-globe", inputs: { mode: "mode", kind: "kind", theme: "theme", countries: "countries", countryLabels: "countryLabels", countryData: "countryData", markers: "markers", htmlMarkers: "htmlMarkers", arcs: "arcs", atmosphere: "atmosphere", focusPulse: "focusPulse", outline: "outline", cinematic: "cinematic", dotted: "dotted", wireframe: "wireframe", paper: "paper", hologram: "hologram", starfield: "starfield", postprocessing: "postprocessing", axisTilt: "axisTilt", autoRotate: "autoRotate", performance: "performance", initialPosition: "initialPosition", minZoom: "minZoom", maxZoom: "maxZoom", zoom: "zoom", transparent: "transparent", framing: "framing" }, outputs: { countryClick: "countryClick", countryHover: "countryHover", markerClick: "markerClick", markerHover: "markerHover", surfaceClick: "surfaceClick", sceneEnter: "sceneEnter", sceneExit: "sceneExit", storyComplete: "storyComplete", ready: "ready", globeError: "globeError" }, viewQueries: [{ propertyName: "host", first: true, predicate: ["host"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: '<div #host class="globe-host"></div>', isInline: true, styles: [":host{display:block;width:100%;height:100%}.globe-host{width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: GlobeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ng-globe', standalone: true, template: '<div #host class="globe-host"></div>', changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;width:100%;height:100%}.globe-host{width:100%;height:100%}\n"] }]
        }], propDecorators: { host: [{
                type: ViewChild,
                args: ['host', { static: true }]
            }], mode: [{
                type: Input
            }], kind: [{
                type: Input
            }], theme: [{
                type: Input
            }], countries: [{
                type: Input
            }], countryLabels: [{
                type: Input
            }], countryData: [{
                type: Input
            }], markers: [{
                type: Input
            }], htmlMarkers: [{
                type: Input
            }], arcs: [{
                type: Input
            }], atmosphere: [{
                type: Input
            }], focusPulse: [{
                type: Input
            }], outline: [{
                type: Input
            }], cinematic: [{
                type: Input
            }], dotted: [{
                type: Input
            }], wireframe: [{
                type: Input
            }], paper: [{
                type: Input
            }], hologram: [{
                type: Input
            }], starfield: [{
                type: Input
            }], postprocessing: [{
                type: Input
            }], axisTilt: [{
                type: Input
            }], autoRotate: [{
                type: Input
            }], performance: [{
                type: Input
            }], initialPosition: [{
                type: Input
            }], minZoom: [{
                type: Input
            }], maxZoom: [{
                type: Input
            }], zoom: [{
                type: Input
            }], transparent: [{
                type: Input
            }], framing: [{
                type: Input
            }], countryClick: [{
                type: Output
            }], countryHover: [{
                type: Output
            }], markerClick: [{
                type: Output
            }], markerHover: [{
                type: Output
            }], surfaceClick: [{
                type: Output
            }], sceneEnter: [{
                type: Output
            }], sceneExit: [{
                type: Output
            }], storyComplete: [{
                type: Output
            }], ready: [{
                type: Output
            }], globeError: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { GlobeComponent };
//# sourceMappingURL=globiojs-angular.mjs.map
